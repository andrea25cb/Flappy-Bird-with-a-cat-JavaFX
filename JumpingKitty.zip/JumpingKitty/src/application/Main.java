package application;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.io.File;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Random;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;
import javafx.scene.control.Label;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.ImagePattern;

public class Main implements ActionListener, KeyListener, ImageObserver {

	public static Main jumpingKitty;

	public final int WIDTH = 800, HEIGHT = 700;

	public Renderer renderer;

	public Rectangle cat;

	public ArrayList<Rectangle> columns;

	public int ticks, yMotion, points;

	public boolean gameOver, started;

	public Random random;

	public Label gameOverL;

	// constructor
	public Main() {
		JFrame view = new JFrame();
		Timer time = new Timer(35, this);

		renderer = new Renderer();
		random = new Random();

		view.add(renderer);
		view.setTitle("JUMPING KITTY");
		view.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		view.setSize(WIDTH, HEIGHT);
		view.addKeyListener(this);
		view.setResizable(false);
		view.setVisible(true);

		cat = new Rectangle(WIDTH / 2 - 10, HEIGHT / 2 - 10, 50, 50);
		
		columns = new ArrayList<Rectangle>();

		addColumn(true);
		addColumn(true);
		addColumn(true);
		addColumn(true);

		time.start();

		Music music = new Music();
	//	music.music("music/songwin.mp3");

	}

	static MediaPlayer mediaPlayer;

	/*public static void music() {
		String s = "music/catsong.mp3";
		Media h = new Media(Paths.get(s).toUri().toString());
		mediaPlayer = new MediaPlayer(h);
		mediaPlayer.play();

	}*/

	public void addColumn(boolean start) {
		int space = 250;// espacio entre top y bottom
		int width = 100;// grosor de las columnas
		int height = 50 + random.nextInt(300); // altura de columnas random

		if (start == true) {
			columns.add(new Rectangle(WIDTH + width + columns.size() * 300, HEIGHT - height - 30, width, height));
			columns.add(new Rectangle(WIDTH + width + (columns.size() - 1) * 300, 0, width, HEIGHT - height - space));
		} else {
			columns.add(new Rectangle(columns.get(columns.size() - 1).x + 500, HEIGHT - height - 30, width, height));
			columns.add(new Rectangle(columns.get(columns.size() - 1).x, 0, width, HEIGHT - height - space));
		}
	}

	public void paintColumn(Graphics g, Rectangle column) {
		g.setColor(Color.gray.darker());
		g.fillRect(column.x, column.y, column.width, column.height);
	}

	// m�todo para que el gato salte
	public void jump() {
		if (gameOver) {
			cat = new Rectangle(WIDTH / 2 - 10, HEIGHT / 2 - 10, 50, 50);
			columns.clear(); // apareces otra vez al principio
			yMotion = 0; // si pierdes el gato aparece en el centro
			points = 0; // si pierdes vuelve a cero el contador

			addColumn(true);
			addColumn(true);
			addColumn(true);
			addColumn(true);

			gameOver = false;
		}

		if (!started) {
			started = true;
		} else if (!gameOver) {
			if (yMotion > 0) {
				yMotion = 0;
			}

			yMotion -= 10; // para que suba
		}
	}// termina jump

	@Override
	public void actionPerformed(ActionEvent e) {
		int speed = 15;
		ticks++;

		if (started) {
			for (int i = 0; i < columns.size(); i++) {
				Rectangle column = columns.get(i);
				column.x -= speed;
			}

			if (ticks % 2 == 0 && yMotion < 15) {
				yMotion += 2;
			}

			for (int i = 0; i < columns.size(); i++) {
				Rectangle column = columns.get(i);

				if (column.x + column.width < 0) {
					columns.remove(column);

					if (column.y == 0) {
						addColumn(false);
					}
				}
			}

			cat.y += yMotion;

			for (Rectangle column : columns) {
				if (column.y == 0 && cat.x + cat.width / 2 > column.x + column.width / 2 - 10
						&& cat.x + cat.width / 2 < column.x + column.width / 2 + 10) {
					points++;// si pasa por el medio suma 1punto
				}

				if (column.intersects(cat)) { // si se chocan, gameover
					gameOver = true;

					if (cat.x <= column.x) {
						cat.x = column.x - cat.width;

					} else {
						if (column.y != 0) {
							cat.y = column.y - cat.height;
						} else if (cat.y < column.height) {
							cat.y = column.height;
						}
					}
				}
			}

			if (cat.y > HEIGHT - 120 || cat.y < 0) { //
				gameOver = true;
			}

			if (cat.y + yMotion >= HEIGHT - 120) {
				cat.y = HEIGHT - 120 - cat.height;
				gameOver = true;
			}
		}

		renderer.repaint(); // IMPORTANTE PARA QUE FUNCIONE LA ANIMACION
	}

	public void repaint(Graphics g) throws Exception {
// background img:
		BufferedImage img;
		img = ImageIO.read(new File("images/bg.png"));
		g.drawImage(img, 0, 0, this);

//cat: 	
		BufferedImage image = ImageIO.read(new File("images/cat.png"));
		g.drawImage(image, 0, 0, null); //no puede cambiarse por el rect�ngulo
		
		g.setColor(Color.gray);
		g.fillRect(cat.x, cat.y, cat.width, cat.height);
        
		for (Rectangle column : columns) {
			paintColumn(g, column);
		}

		g.setColor(Color.yellow);
		g.setFont(new Font("Impact", 2, 75));

		if (!started) {
			g.drawString("press space to start", 50, HEIGHT / 2 - 50);
		}
		if (gameOver) {
			g.drawString("GAME OVER...", 50, HEIGHT / 2 - 50);
			g.setFont(new Font("Arial", Font.BOLD, 30));
			g.drawString("press space to restart", 60, 350);
		}
		if (!gameOver && started) {
			g.drawString(String.valueOf(points), WIDTH / 2 - 25, 100);
		}
		if (points == 5) {
			g.drawString("wow!!", 50, HEIGHT / 2 - 50);
		}
		if (points == 15) {
			g.drawString("amazing!", 50, HEIGHT / 2 - 50);
		}
		if (points == 25) {
			g.drawString("on fire!!!", 50, HEIGHT / 2 - 50);
		}
		if (points == 35) {
			g.drawString("u rock", 50, HEIGHT / 2 - 50);
		}
	}// fin metodo repaint

	public static void main(String[] args) {
		jumpingKitty = new Main();

	}

	@Override
	public void keyReleased(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_SPACE) {
			jump();
		}
	}

	@Override
	public void keyTyped(KeyEvent e) {

	}

	@Override
	public void keyPressed(KeyEvent e) {

	}

	@Override
	public boolean imageUpdate(Image img, int infoflags, int x, int y, int width, int height) {
		return false;
	}

}
